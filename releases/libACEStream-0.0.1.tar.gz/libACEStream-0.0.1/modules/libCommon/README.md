# libCommon
(wrapper) library of common functions (*NOTE*: uses ACE, see: http://www.cs.wustl.edu/~schmidt/ACE.html)
