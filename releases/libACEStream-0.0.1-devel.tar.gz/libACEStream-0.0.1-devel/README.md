# libACEStream
wrapper library of ACE streams (see: http://www.dre.vanderbilt.edu/Doxygen/Stable/libace-doc/a00645.html)
