# libACENetwork
(wrapper) library for ACE network functionality (see: http://www.cs.wustl.edu/~schmidt/ACE.html)
